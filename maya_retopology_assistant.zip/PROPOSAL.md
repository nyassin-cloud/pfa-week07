# Maya Character Retopology Assistant

I will build a Python tool inside Maya that helps artists generate, compare, and review automatic retopology for characters and creatures. The tool will use Maya's existing `polyRetopo` engine. My contribution will be the workflow around it: checking the source mesh, marking important regions, comparing candidates, and measuring how closely the result follows the original surface.

Retopology is more than polygon reduction. Artists need to preserve shape and important features while preparing a mesh for manual refinement and animation. Fully automatic animation-ready edge flow is outside this project's scope. My tool will create a useful starting mesh and help artists identify areas that need attention.

## One-window interface

- Use Selected Mesh button and source mesh name.
- Mesh readiness check for nonmanifold edges and vertices, lamina faces, and disconnected shells.
- Target face count, Preserve Hard Edges, preprocessing, and optional X symmetry controls.
- Mark Face Region and Mark Joint Region buttons that save selected source faces in named selection sets for review and manual cleanup.
- Generate Preview button that produces an independent candidate without editing source geometry.
- Candidate list for comparing different polygon budgets and settings.
- Show Original, Show Candidate, and Overlay controls.
- Distance heat map showing how far candidate vertices are from the source surface saved at generation time.
- Accept Result, Discard Preview, and Reset Settings buttons.
- Status area showing warnings, settings, generation time, and actual face counts.

## Technical contribution

The project separates mesh generation from evaluation. Artists can compare multiple results and inspect where a result drifts from the source. Marked face and joint regions support focused manual review; the first version will not automatically create anatomical loops or allocate extra polygons to these regions.

The heat map will use a consistent distance threshold across candidates. It measures unsigned distances from candidate vertices to the original surface. This is a review aid, not a complete surface-error measurement or proof that the mesh will deform well.

## Schedule

- **October 13:** Working UI, mesh selection, and a basic retopology experiment on a test mesh.
- **October 20:** Independent previews on a symmetrical humanoid, target face count and symmetry controls, mesh validation, candidate comparison, and accept/discard workflow.
- **October 26:** Distance heat map, region marking, error handling, testing, and final demonstration.

These are planned milestones, not claims of completed testing.

## Smallest version that still counts

A working Maya window that generates automatic retopology from one selected mesh, lets the artist control the target face count, and accepts or discards the result without changing original mesh geometry. It runs entirely inside Maya.

## Evaluation

I will test a symmetrical humanoid and one additional mesh. For each, I will compare at least two polygon budgets, record actual face counts and generation times, inspect silhouettes and distance heat maps, and review marked face or joint regions. I will also test invalid inputs and confirm that discarding a preview leaves source geometry intact.

## Stretch goals

1. A simple elbow or knee deformation test on a separate copy of an accepted result.
2. Artist-marked feature edges connected to Maya's feature preservation controls.
3. Investigate local density guidance within an approximate overall face budget.
4. UV generation if the core workflow is stable.

## Risks

Maya's engine may miss the requested face count or produce topology requiring manual cleanup. Dense meshes may process slowly. Vertex-to-surface measurements can miss errors between vertices and around nearby surfaces. The tool will report actual results and these limits instead of labeling output animation-ready.

## References

- [Autodesk: polyRetopo command](https://help.autodesk.com/cloudhelp/2026/ENU/Maya-Tech-Docs/CommandsPython/polyRetopo.html)
- [Autodesk: Retopologize settings](https://help.autodesk.com/cloudhelp/2026/ENU/Maya-Modeling/files/GUID-FDE163EE-39C1-421E-AC31-9956D21F6D0F.htm)
- [Autodesk: polyRetopo node](https://help.autodesk.com/cloudhelp/2026/ENU/Maya-Tech-Docs/Nodes/polyRetopo.html)
