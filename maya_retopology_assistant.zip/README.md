# Maya Character Retopology Assistant

Read `PROPOSAL.md` for the rewritten project pitch. `retopo_assistant.py` is the implementation.

## Run in Maya

Designed for Maya with Python 3 and the built-in `polyRetopo` command (Maya 2022 or newer is the intended target). This build has not been executed in Maya yet; version compatibility and output quality still need Maya-side verification.

1. Open Maya and its **Windows > General Editors > Script Editor**.
2. Choose a **Python** tab.
3. Paste and run:

```python
import sys
import importlib
folder = r'C:\Users\free\Documents\maya_retopology_assistant'
if folder not in sys.path:
    sys.path.insert(0, folder)
import retopo_assistant
importlib.reload(retopo_assistant)
retopo_assistant.show()
```

Keep this folder in place. You can also save this snippet as a Python shelf button. To reload after editing code, close the tool window before rerunning the snippet.

## Workflow

1. Select one polygon mesh object and click **Use Selected Mesh**.
2. Read the readiness report. Fix nonmanifold or lamina geometry manually before generating. Disconnected shells produce a warning.
3. Optionally select source faces and mark a face or joint region. Marking adds to the corresponding selection set. Edit its membership through Maya's Set Editor if needed. These sets stay on the source for manual cleanup and do not influence retopology.
4. Enter a target face count. Enable symmetry only when the character matches the indicated object-pivot X plane. Preprocessing is intended for dense meshes and can smooth detail. Preserve Hard Edges influences existing hard edges; it does not identify eyes or joints.
5. Click **Generate Preview**. Maya may be unresponsive while its native engine runs; there is no cancel button or invented percentage progress. Wait for completion.
6. Change settings and generate another candidate. Select list entries and compare actual face counts and timing in the status area. Original/Candidate/Overlay switches visibility. For the overlay, enable **Shading > Wireframe on Shaded** in your viewport; coincident surfaces may flicker. Hidden parent groups or display layers can prevent the source from appearing.
7. Set a positive distance threshold in current scene units and calculate the heat map. Blue means zero distance; red means the threshold or greater. Intermediate colors pass through cyan/yellow. Use the same threshold and units to compare candidates. Heat map colors may require viewport color display support with your chosen material/render mode; previews use Maya's default material.
8. **Select Non-Quad Faces** highlights triangles and n-gons for inspection. This is not an animation-quality score.
9. **Accept** keeps an independent result and removes its private source snapshot. **Discard** deletes only that candidate and its snapshot. The original geometry, materials and history are not edited. Display controls temporarily change source visibility; accept, final discard, and window close restore its initial visibility.

## Scope and lifecycle

- Each candidate uses a separate evaluated source snapshot, so its heat map refers to the source at generation time. Generation copies mesh data, not the source rig or upstream history. Results use the default material; UVs, shading transfer and skeleton generation are not promised.
- The target is approximate; the tool reports actual face counts and warns when they fall outside 10% of the request.
- The heat map is an unsigned, one-way closest-surface distance at candidate vertices. It can miss errors between vertices, missing source detail, and incorrect correspondences across nearby surfaces. It does not measure deformation.
- Heat map computation is linear in candidate vertex samples with native closest-point queries and can be slow on dense results.
- Region selection sets are retained in the Maya scene. Candidate list state is only kept while the window is open. Closing keeps previews as ordinary visible meshes and deletes hidden reference snapshots. Accepted results keep the heat map color set but disable its display.
- Use the tool's Accept/Discard controls during a session. Maya Undo/Redo does not synchronize the Python candidate list; close and reopen the tool if scene undo or manual deletion invalidates tracked objects. Direct OpenMaya mesh/color operations are not fully covered by Maya undo.
- Multiple mesh shapes, instanced shapes, and locked or connected source visibility are rejected. Referenced or constrained scenes may need a separate editable mesh copy. Work on a saved scene when trying the prototype.
- Automatic anatomical loops, local density allocation, UV generation and deformation tests are stretch goals, not implemented features.

## Verification

No runnable Maya or Python interpreter was available in the build environment. The included smoke test is provided for execution in Maya; it has not been run here. It creates its own test objects without clearing your scene and removes them afterward. Run it with the tool closed, preferably in a test scene:

```python
import sys
folder = r'C:\Users\free\Documents\maya_retopology_assistant'
if folder not in sys.path:
    sys.path.insert(0, folder)
import maya_smoke_test
maya_smoke_test.run()
```

The test checks source preservation, invalid face-count handling, region marking, multiple candidates, heat map creation, discard, accept and close cleanup. Also test on your actual humanoid and a second mesh; inspect silhouette, eyelids, mouth corners and joint bends manually. Native retopology of a sphere is not evidence of animation-ready topology.

## Demo outline

Show the sculpt and its face count. Mark a face and a joint region. Generate two candidates at different budgets. Compare silhouettes, actual face counts and timings. Show both heat maps at one threshold. Highlight a problem region and explain what still needs manual cleanup. Discard one result and accept the other, showing that the original remains available.

## Autodesk references

- [Retopologize settings and limitations](https://help.autodesk.com/cloudhelp/2026/ENU/Maya-Modeling/files/GUID-FDE163EE-39C1-421E-AC31-9956D21F6D0F.htm)
- [polyRetopo node attributes](https://help.autodesk.com/cloudhelp/2026/ENU/Maya-Tech-Docs/Nodes/polyRetopo.html)
- [polyRetopo command](https://help.autodesk.com/cloudhelp/2026/ENU/Maya-Tech-Docs/CommandsPython/polyRetopo.html)
