"""Character retopology review tool. Run show() inside Maya Python 3.

Uses Maya's polyRetopo engine. Region sets are for review, not density control.
"""
import math
import time
import traceback
import uuid
import maya.cmds as cmds
import maya.api.OpenMaya as om

WINDOW = 'noraCharacterRetopoAssistant'
_INSTANCE = None


def shape(node):
    shapes = cmds.listRelatives(node, shapes=True, noIntermediate=True,
                                fullPath=True, type='mesh') or []
    if len(shapes) != 1:
        raise ValueError('Choose one transform containing exactly one polygon mesh.')
    return shapes[0]


def mesh(node):
    selection = om.MSelectionList()
    selection.add(shape(node))
    return om.MFnMesh(selection.getDagPath(0))


def resolve(identifier):
    nodes = cmds.ls(identifier, long=True) or []
    if len(nodes) != 1:
        raise ValueError('A tracked mesh was deleted or is ambiguous. Reselect the source.')
    return nodes[0]


def readiness(node):
    result = {flag: cmds.polyInfo(node, **{flag: True}) or [] for flag in
              ('nonManifoldEdges', 'nonManifoldVertices', 'laminaFaces')}
    result['shells'] = int(cmds.polyEvaluate(node, shell=True))
    result['faces'] = int(cmds.polyEvaluate(node, face=True))
    return result


def baked_copy(source, name):
    """Copy only evaluated mesh data, never a rig, hierarchy or upstream history."""
    node = cmds.createNode('transform', name=name)
    try:
        selection = om.MSelectionList()
        selection.add(node)
        om.MFnMesh().copy(mesh(source).object(), selection.getDependNode(0))
        cmds.xform(node, worldSpace=True, matrix=cmds.xform(source, query=True,
                                                        worldSpace=True, matrix=True))
        pivot = cmds.xform(source, query=True, objectSpace=True, rotatePivot=True)
        cmds.xform(node, objectSpace=True, pivots=pivot, preserve=True)
        cmds.sets(node, edit=True, forceElement='initialShadingGroup')
        return cmds.ls(node, long=True)[0]
    except Exception:
        cmds.delete(node)
        raise


class Assistant:
    def __init__(self):
        self.source_id = None
        self.original_visibility = None
        self.candidates = []
        self.regions = {}
        self.ui = {}
        self.busy = False
        self.closed = False
        self.token = uuid.uuid4().hex[:8]
        self.build()

    def action(self, function, *args):
        if self.busy:
            return
        self.busy = True
        cmds.waitCursor(state=True)
        cmds.undoInfo(openChunk=True, chunkName='Retopology Assistant')
        try:
            function(*args)
        except Exception as exc:
            self.log('ERROR: ' + str(exc))
            cmds.warning(str(exc))
            traceback.print_exc()
        finally:
            cmds.undoInfo(closeChunk=True)
            cmds.waitCursor(state=False)
            self.busy = False

    def button(self, label, function, *args):
        cmds.button(label=label, command=lambda *_: self.action(function, *args))

    def build(self):
        cmds.window(WINDOW, title='Maya Character Retopology Assistant',
                    widthHeight=(540, 820), closeCommand=lambda *_: self.close())
        cmds.scrollLayout(childResizable=True)
        cmds.columnLayout(adjustableColumn=True, rowSpacing=6)
        cmds.text(label='Generate with Maya. Compare and refine with artist judgment.', align='left')
        self.button('Use Selected Mesh', self.use_selected)
        self.ui['source'] = cmds.text(label='Source: none', align='left')
        self.button('Check Mesh Readiness', self.check)
        self.ui['target'] = cmds.intFieldGrp(label='Target face count', value1=5000)
        self.ui['hard'] = cmds.checkBox(label='Preserve hard edges', value=True)
        self.ui['preprocess'] = cmds.checkBox(label='Preprocess dense mesh (may smooth details)', value=False)
        self.ui['symmetry'] = cmds.checkBox(label='X symmetry (+X to -X, object pivot)', value=False)
        cmds.separator()
        cmds.text(label='Mark SOURCE faces for review. Marks do not control polygon density.',
                  align='left', wordWrap=True)
        for region, label in [('face', 'Face'), ('joints', 'Joint')]:
            self.button('Mark ' + label + ' Region', self.mark, region)
            self.button('Select Marked ' + label + ' Region', self.select_region, region)
        cmds.separator()
        self.button('Generate Preview', self.generate)
        self.ui['candidates'] = cmds.textScrollList(numberOfRows=4, allowMultiSelection=False,
            selectCommand=lambda *_: self.action(self.display, 'Candidate'))
        for mode in ('Original', 'Candidate', 'Overlay'):
            self.button('Show ' + mode, self.display, mode)
        cmds.text(label='For overlay, enable Shading > Wireframe on Shaded in your viewport.',
                  align='left', wordWrap=True)
        self.ui['threshold'] = cmds.floatFieldGrp(label='Heat map red distance', value1=0.1, precision=4)
        cmds.text(label='Current Maya units: blue = zero; red = threshold or higher.', align='left')
        self.button('Calculate / Show Distance Heat Map', self.heatmap)
        self.button('Hide Heat Map', self.hide_heatmap)
        self.button('Select Non-Quad Faces', self.inspect)
        self.button('Accept Selected Result', self.accept)
        self.button('Discard Selected Preview', self.discard)
        self.button('Reset Settings', self.reset)
        self.ui['status'] = cmds.scrollField(editable=False, wordWrap=True, height=150, text='Ready.\n')
        cmds.showWindow(WINDOW)

    def log(self, message):
        old = cmds.scrollField(self.ui['status'], query=True, text=True)
        cmds.scrollField(self.ui['status'], edit=True, text=(old + message + '\n')[-18000:])

    def source(self):
        if not self.source_id:
            raise ValueError('Use Selected Mesh first.')
        return resolve(self.source_id)

    def use_selected(self):
        if self.candidates:
            raise ValueError('Accept or discard all previews before changing source.')
        nodes = cmds.ls(selection=True, objectsOnly=True, long=True) or []
        if len(nodes) != 1:
            raise ValueError('Select one polygon mesh object.')
        node = nodes[0]
        if cmds.nodeType(node) == 'mesh':
            node = cmds.listRelatives(node, parent=True, fullPath=True)[0]
        shape(node)
        if len(cmds.ls(shape(node), long=True, allPaths=True) or []) != 1:
            raise ValueError('Instanced transforms are unsupported; use a separate copy.')
        if not cmds.getAttr(node + '.visibility', settable=True):
            raise ValueError('Source visibility is locked or connected; use an editable copy.')
        self.restore_source()
        self.source_id = cmds.ls(node, uuid=True)[0]
        self.original_visibility = cmds.getAttr(node + '.visibility')
        self.regions = {}
        cmds.text(self.ui['source'], edit=True, label='Source: ' + node)
        self.check()

    def check(self):
        report = readiness(self.source())
        self.log('Source: {faces:,} faces; {shells} shell(s).'.format(**report))
        for flag in ('nonManifoldEdges', 'nonManifoldVertices', 'laminaFaces'):
            self.log('{}: {} reported item(s).'.format(flag, len(report[flag])))
        if report['shells'] > 1:
            self.log('WARNING: disconnected shells may retopologize independently.')
        return report

    def mark(self, region):
        self.source()
        faces = cmds.filterExpand(cmds.ls(selection=True, long=True),
                                  selectionMask=34, expand=True) or []
        if not faces:
            raise ValueError('Select source polygon faces in component mode first.')
        for face in faces:
            owner = face.split('.f[')[0]
            if cmds.nodeType(owner) == 'mesh':
                owner = cmds.listRelatives(owner, parent=True, fullPath=True)[0]
            if (cmds.ls(owner, uuid=True) or [None])[0] != self.source_id:
                raise ValueError('Mark faces on the source only.')
        region_set = self.regions.get(region)
        if not region_set or not cmds.objExists(region_set):
            region_set = cmds.sets(empty=True, name='RA_{}_{}_SET'.format(self.token, region))
            self.regions[region] = region_set
        cmds.sets(faces, add=region_set)
        self.log('Saved {} face(s) to {}. Review only.'.format(
            len(cmds.sets(region_set, query=True) or []), region_set))

    def select_region(self, region):
        region_set = self.regions.get(region)
        if not region_set or not cmds.objExists(region_set):
            raise ValueError('Mark this region first.')
        self.display('Original')
        cmds.select(cmds.sets(region_set, query=True) or [], replace=True)

    def generate(self):
        source = self.source()
        report = self.check()
        if any(report[key] for key in ('nonManifoldEdges', 'nonManifoldVertices', 'laminaFaces')):
            raise ValueError('Fix nonmanifold or lamina geometry first. Source was not changed.')
        if not report['faces']:
            raise ValueError('Source has no faces.')
        target = cmds.intFieldGrp(self.ui['target'], query=True, value1=True)
        if target < 4:
            raise ValueError('Target face count must be at least 4.')
        settings = dict(targetFaceCount=target, targetFaceCountTolerance=10,
            preserveHardEdges=cmds.checkBox(self.ui['hard'], query=True, value=True),
            preprocessMesh=cmds.checkBox(self.ui['preprocess'], query=True, value=True),
            symmetry=cmds.checkBox(self.ui['symmetry'], query=True, value=True))
        self.log('Generating: {}. Maya may be busy until its engine finishes.'.format(settings))
        cmds.refresh()
        started = time.perf_counter()
        preview = snapshot = None
        saved_selection = cmds.ls(selection=True, long=True) or []
        try:
            snapshot = baked_copy(source, 'RA_sourceSnapshot#')
            cmds.setAttr(snapshot + '.visibility', 0)
            preview = baked_copy(snapshot, 'RA_preview#')
            cmds.setAttr(preview + '.visibility', 1)
            cmds.select(preview, replace=True)
            result = cmds.polyRetopo()
            nodes = ([result] if isinstance(result, str) else list(result or []))
            nodes += cmds.listHistory(preview) or []
            retopo = next((n for n in nodes if cmds.objExists(n) and cmds.nodeType(n) == 'polyRetopo'), None)
            if not retopo:
                raise RuntimeError('Maya did not create a polyRetopo node.')
            for attribute, value in settings.items():
                if not cmds.attributeQuery(attribute, node=retopo, exists=True):
                    raise RuntimeError('This Maya version lacks polyRetopo.' + attribute)
                cmds.setAttr(retopo + '.' + attribute, value)
            if settings['symmetry']:
                cmds.setAttr(retopo + '.axis', 0)
                cmds.setAttr(retopo + '.axisPosition', 0)
            count = int(cmds.polyEvaluate(preview, face=True))
            if not count:
                raise RuntimeError('Retopology produced an empty result.')
            cmds.delete(preview, constructionHistory=True)
            candidate = dict(id=cmds.ls(preview, uuid=True)[0],
                snapshot_id=cmds.ls(snapshot, uuid=True)[0], settings=settings,
                faces=count, source_faces=report['faces'], seconds=time.perf_counter() - started)
            self.candidates.append(candidate)
            preview = snapshot = None
            self.refresh_list(len(self.candidates))
            self.log('Candidate: {:,} -> {:,} faces ({:.1f}% reduction); {:.2f}s.'.format(
                report['faces'], count, 100 * (1 - count / float(report['faces'])), candidate['seconds']))
            if abs(count - target) > target * 0.1:
                self.log('WARNING: actual face count is outside the requested 10% tolerance.')
            self.display('Candidate')
        finally:
            for temporary in (preview, snapshot):
                if temporary and cmds.objExists(temporary):
                    cmds.delete(temporary)
            remaining = [n for n in saved_selection if cmds.objExists(n)]
            cmds.select(remaining, replace=True) if remaining else cmds.select(clear=True)

    def refresh_list(self, index=1):
        cmds.textScrollList(self.ui['candidates'], edit=True, removeAll=True)
        for number, candidate in enumerate(self.candidates, 1):
            cmds.textScrollList(self.ui['candidates'], edit=True,
                append='{}: {:,} faces | target {:,} | {:.2f}s'.format(number,
                    candidate['faces'], candidate['settings']['targetFaceCount'], candidate['seconds']))
        if self.candidates:
            cmds.textScrollList(self.ui['candidates'], edit=True,
                                selectIndexedItem=min(index, len(self.candidates)))

    def current(self):
        indices = cmds.textScrollList(self.ui['candidates'], query=True, selectIndexedItem=True) or []
        if not indices or indices[0] > len(self.candidates):
            raise ValueError('Generate and select a preview first.')
        candidate = self.candidates[indices[0] - 1]
        resolve(candidate['id'])
        return candidate

    def display(self, mode):
        selected = self.current() if mode != 'Original' else None
        cmds.setAttr(self.source() + '.visibility', mode in ('Original', 'Overlay'))
        for candidate in self.candidates:
            nodes = cmds.ls(candidate['id'], long=True) or []
            if nodes:
                cmds.setAttr(nodes[0] + '.visibility', candidate is selected)
        if selected:
            cmds.select(resolve(selected['id']), replace=True)

    def heatmap(self):
        candidate = self.current()
        preview = resolve(candidate['id'])
        threshold = cmds.floatFieldGrp(self.ui['threshold'], query=True, value1=True)
        if not math.isfinite(threshold) or threshold <= 0:
            raise ValueError('Heat map distance must be positive and finite.')
        source_fn = mesh(resolve(candidate['snapshot_id']))
        output_fn = mesh(preview)
        points = output_fn.getPoints(om.MSpace.kWorld)
        if not points:
            raise ValueError('Candidate has no vertices.')
        colors, distances = [], []
        self.log('Measuring candidate vertices against saved source surface...')
        cmds.refresh()
        for point in points:
            closest, _ = source_fn.getClosestPoint(point, om.MSpace.kWorld)
            # OpenMaya positions use centimeters; the UI uses current scene units.
            distance = om.MDistance((point - closest).length(),
                                   om.MDistance.kCentimeters).asUnits(om.MDistance.uiUnit())
            distances.append(distance)
            fraction = min(distance / threshold, 1.0)
            colors.append(om.MColor((min(2 * fraction, 1.0),
                1.0 - abs(2 * fraction - 1.0), max(1.0 - 2 * fraction, 0.0), 1.0)))
        color_set = candidate.get('color_set')
        if not color_set or color_set not in output_fn.getColorSetNames():
            color_set = output_fn.createColorSetWithName('RA_distance_' + self.token)
            candidate['color_set'] = color_set
        output_fn.setCurrentColorSetName(color_set)
        output_fn.setVertexColors(colors, list(range(len(points))))
        cmds.setAttr(shape(preview) + '.displayColors', 1)
        self.log('Vertex-to-source distance: mean {:.6g}, max {:.6g} {}; red >= {:.6g}.'.format(
            sum(distances) / len(distances), max(distances),
            cmds.currentUnit(query=True, linear=True), threshold))
        self.log('Unsigned one-way vertex samples; not a deformation or full surface-error metric.')
        self.display('Candidate')

    def hide_heatmap(self):
        cmds.setAttr(shape(resolve(self.current()['id'])) + '.displayColors', 0)

    def inspect(self):
        node = resolve(self.current()['id'])
        fn = mesh(node)
        faces = [node + '.f[{}]'.format(i) for i in range(fn.numPolygons)
                 if fn.polygonVertexCount(i) != 4]
        self.display('Candidate')
        cmds.select(faces, replace=True) if faces else cmds.select(clear=True)
        self.log('{} non-quad faces selected. Quads alone do not prove animation quality.'.format(len(faces)))

    def remove_snapshot(self, candidate):
        nodes = cmds.ls(candidate['snapshot_id'], long=True) or []
        if nodes:
            cmds.delete(nodes)

    def accept(self):
        candidate = self.current()
        node = resolve(candidate['id'])
        cmds.setAttr(shape(node) + '.displayColors', 0)
        node = cmds.rename(node, 'RA_accepted#')
        self.remove_snapshot(candidate)
        self.candidates.remove(candidate)
        self.refresh_list()
        self.restore_source()
        cmds.setAttr(node + '.visibility', 1)
        cmds.select(node, replace=True)
        self.log('Accepted {}. Source geometry unchanged. Region sets remain on source.'.format(node))

    def discard(self):
        candidate = self.current()
        cmds.delete(resolve(candidate['id']))
        self.remove_snapshot(candidate)
        self.candidates.remove(candidate)
        self.refresh_list()
        if self.candidates:
            self.display('Candidate')
        else:
            self.restore_source()
        self.log('Discarded selected preview and reference snapshot.')

    def reset(self):
        cmds.intFieldGrp(self.ui['target'], edit=True, value1=5000)
        cmds.checkBox(self.ui['hard'], edit=True, value=True)
        cmds.checkBox(self.ui['preprocess'], edit=True, value=False)
        cmds.checkBox(self.ui['symmetry'], edit=True, value=False)
        cmds.floatFieldGrp(self.ui['threshold'], edit=True, value1=0.1)
        self.log('Settings reset. Existing previews and region sets retained.')

    def restore_source(self):
        nodes = cmds.ls(self.source_id, long=True) if self.source_id else []
        if nodes and cmds.getAttr(nodes[0] + '.visibility', settable=True):
            cmds.setAttr(nodes[0] + '.visibility', self.original_visibility)

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.restore_source()
        for candidate in self.candidates:
            try:
                self.remove_snapshot(candidate)
                nodes = cmds.ls(candidate['id'], long=True) or []
                if nodes:
                    cmds.setAttr(nodes[0] + '.visibility', 1)
                    cmds.setAttr(shape(nodes[0]) + '.displayColors', 0)
            except Exception as exc:
                cmds.warning('Preview cleanup: ' + str(exc))


def show():
    """Open the window and return its controller for Maya-side testing."""
    global _INSTANCE
    if _INSTANCE is not None:
        _INSTANCE.close()
    if cmds.window(WINDOW, exists=True):
        cmds.deleteUI(WINDOW)
    _INSTANCE = Assistant()
    return _INSTANCE
