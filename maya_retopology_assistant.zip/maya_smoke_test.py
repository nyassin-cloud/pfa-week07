"""Run run() in Maya's Python Script Editor; does not clear the user's scene."""
import maya.cmds as cmds
import maya.api.OpenMaya as om
import retopo_assistant as ra


def fingerprint(node):
    fn = ra.mesh(node)
    return (fn.numVertices, fn.numPolygons,
            [(p.x, p.y, p.z) for p in fn.getPoints(om.MSpace.kWorld)],
            list(fn.getVertices()[0]), list(fn.getVertices()[1]),
            sorted(cmds.listHistory(node) or []))


def run():
    if cmds.window(ra.WINDOW, exists=True):
        raise RuntimeError('Close the retopology tool before running this test.')
    saved_selection = cmds.ls(selection=True, long=True) or []
    source = tool = None
    created_ids = []
    region_sets = []
    try:
        source = cmds.polySphere(name='RA_smoke_source#', subdivisionsX=24,
                                 subdivisionsY=16, constructionHistory=True)[0]
        created_ids.append(cmds.ls(source, uuid=True)[0])
        cmds.xform(source, translation=(2.0, 1.0, -3.0), rotation=(10, 20, 5),
                   scale=(1.2, 0.9, 1.1))
        before = fingerprint(source)
        cmds.select(source, replace=True)
        tool = ra.show()
        tool.use_selected()
        assert tool.check()['faces'] > 0
        cmds.select(source + '.f[0:5]', replace=True)
        tool.mark('face')
        region_sets.extend(tool.regions.values())
        assert len(cmds.sets(tool.regions['face'], query=True)) == 6
        cmds.intFieldGrp(tool.ui['target'], edit=True, value1=0)
        try:
            tool.generate()
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid target should fail.')
        assert not tool.candidates
        for target in (160, 260):
            cmds.intFieldGrp(tool.ui['target'], edit=True, value1=target)
            tool.generate()
            candidate = tool.current()
            created_ids.extend([candidate['id'], candidate['snapshot_id']])
            source_points = ra.mesh(source).getPoints(om.MSpace.kWorld)
            snapshot_points = ra.mesh(ra.resolve(candidate['snapshot_id'])).getPoints(om.MSpace.kWorld)
            assert len(source_points) == len(snapshot_points)
            assert all((a - b).length() < 1e-5 for a, b in zip(source_points, snapshot_points)), \
                'Snapshot does not preserve transformed source positions.'
        assert len(tool.candidates) == 2
        assert before == fingerprint(source), 'Source geometry or history changed.'
        tool.display('Original')
        assert cmds.getAttr(source + '.visibility')
        tool.display('Candidate')
        assert not cmds.getAttr(source + '.visibility')
        tool.heatmap()
        candidate = tool.current()
        assert candidate['color_set'] in ra.mesh(ra.resolve(candidate['id'])).getColorSetNames()
        tool.hide_heatmap()
        doomed = candidate['id']
        snapshot = candidate['snapshot_id']
        tool.discard()
        assert not cmds.ls(doomed) and not cmds.ls(snapshot)
        accepted = tool.current()['id']
        tool.accept()
        assert cmds.ls(accepted)
        assert not tool.candidates
        assert cmds.getAttr(source + '.visibility')
        assert before == fingerprint(source), 'Source changed during accept/discard.'
        # Exercise closing with a remaining preview: keep mesh, remove snapshot.
        cmds.intFieldGrp(tool.ui['target'], edit=True, value1=180)
        tool.generate()
        last = tool.current()
        created_ids.extend([last['id'], last['snapshot_id']])
        tool.close()
        assert not cmds.ls(last['snapshot_id'])
        assert cmds.getAttr(ra.resolve(last['id']) + '.visibility')
        assert cmds.getAttr(source + '.visibility')
        assert before == fingerprint(source)
        print('PASS: retopology assistant smoke test. Test mesh only; inspect character results manually.')
    finally:
        if tool is not None:
            tool.close()
        if cmds.window(ra.WINDOW, exists=True):
            cmds.deleteUI(ra.WINDOW)
        for identifier in created_ids:
            nodes = cmds.ls(identifier, long=True) or []
            if nodes:
                cmds.delete(nodes)
        for region_set in region_sets:
            if cmds.objExists(region_set):
                cmds.delete(region_set)
        remaining = [node for node in saved_selection if cmds.objExists(node)]
        cmds.select(remaining, replace=True) if remaining else cmds.select(clear=True)
